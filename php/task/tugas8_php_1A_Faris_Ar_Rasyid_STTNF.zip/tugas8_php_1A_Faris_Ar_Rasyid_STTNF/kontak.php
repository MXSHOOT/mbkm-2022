<fieldset>
        <legend><h2>Kontak me</h2></legend>    
        <p align="justify">
        <font size="4" face="arial" color="black">    
        <p align="center">
            <img src="https://avatars.githubusercontent.com/u/48386460?v=4" width="20%" border="2" /><br/>
            Faris Ar Rasyid<br/>
            Instagram : <a href="https://www.instagram.com/faris.arrasyid/?hl=id">@faris.arrasyid</a><br/>
            Github : <a href="https://github.com/MXSHOOT">MXSHOOT</a>
        </p>
        </font>
        </p>
    </fieldset>