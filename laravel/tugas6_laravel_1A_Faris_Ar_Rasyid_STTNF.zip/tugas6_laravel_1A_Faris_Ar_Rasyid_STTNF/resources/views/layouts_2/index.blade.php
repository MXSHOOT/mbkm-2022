@include('layouts_2.header')
@include('layouts_2.menu')
@yield('content')
@include('layouts_2.footer')