  <fieldset>
        <legend>Gallery Harimau Putih</legend>
        <marquee scrolldelay="60" direction="Right">
            <img src="https://1.bp.blogspot.com/-hXB32hPYR3o/U0zjI6I4f3I/AAAAAAAABAI/wtvzA4RseVk/s1600/White-Tiger-5.jpg" width="600px" height="400px" >&nbsp;&nbsp;
            <img src="https://1.bp.blogspot.com/-Nms-D5-7KtE/U0zjH4gEbZI/AAAAAAAAA_4/hNfEfxxxuH0/s1600/White-Tiger-3.jpg" width="600px" height="400px">&nbsp;&nbsp;
            <img src="https://1.bp.blogspot.com/-WI0znZAsmhw/U0zjJYG4_UI/AAAAAAAABAQ/vJC6qUzF87A/s1600/White-Tiger-6.jpg" width="600px" height="400px">&nbsp;&nbsp;
            <img src="https://3.bp.blogspot.com/-kBNt_gD6sGI/U0zjK2V57QI/AAAAAAAABAw/eYczYnPYic4/s1600/White-Tiger-9.jpg" width="600px" height="400px">&nbsp;&nbsp;
            <img src="https://2.bp.blogspot.com/-yu77hPr16hE/U0zjE_tlHdI/AAAAAAAAA_I/YE1Dl5v7xJ0/s1600/White-Tiger-14.jpg" width="600px" height="400px">&nbsp;&nbsp;
            <img src="https://4.bp.blogspot.com/-QJTE5HraZY8/U0zjG_A6CZI/AAAAAAAAA_k/5Js7ZJbVeM0/s1600/White-Tiger-18.jpg" width="600px" height="400px">&nbsp;&nbsp;
        </marquee>    
    </fieldset>  