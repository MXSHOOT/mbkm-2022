@extends('layouts_2.index')
@section('content')
<!--================Banner Area =================-->
<section class="banner_area">
    <div class="booking_table d_flex align-items-center">
        <div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background="">
        </div>
        <div class="container">
            <div class="banner_content text-center">
                <h6>WELCOME TO</h6>
                <h2>Latihan Laravel</h2>
                <p>Laravel Development.</p>
                <a href="#" class="btn theme_btn button_hover">Get Started</a>
            </div>
        </div>
    </div>
</section>
<!--================Banner Area =================-->
@endsection