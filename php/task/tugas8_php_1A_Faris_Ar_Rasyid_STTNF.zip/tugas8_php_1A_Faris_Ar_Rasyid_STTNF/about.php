<legend><h2>Profile</h2></legend>   
        <a href="#bawah">
            <img src="https://icons.iconarchive.com/icons/paomedia/small-n-flat/256/sign-down-icon.png" align="right" width="3%" />    
        </a> 
        <p align="justify">
        <img src="https://avatars.githubusercontent.com/u/48386460?v=4" align="left" width="5%" hspace="10" border="2" />
        <font size="4" face="arial" color="black">    
        Hai! perkenalkan nama saya Faris Ar Rasyid, saya seorang manusia. saya paham ini apasih maksudnya manusia, biar kujelaskan, jadi manusia itu merupakan mahkluk yang memiliki ciri khusus yaitu bergerak dengan berfikir dan memiliki kecerdasan yang luar biasa dari mahkluk lainnya. ada yang berkata manusia adalah mahkluk sempurna yang disebabkan karena manusia merupakan satu-satunya mahkluk yang menduduki paling atas dibumi jadi wajar ada asumsi berikut, ini terjadi karena proses pikir manusia yang mengganggap demikian dari keyakinan ini manusia tidaklah memikirkan keras apa yang ia tidak ketahui dibuat tahu. alasannya mengapa? akan terjawab di paragraf berikut. 
        </font>
        </p>
        </fieldset>