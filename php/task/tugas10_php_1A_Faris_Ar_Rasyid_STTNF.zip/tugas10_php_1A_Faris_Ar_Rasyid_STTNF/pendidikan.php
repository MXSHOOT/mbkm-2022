
            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-12">
                        <div class="bg-light rounded h-100 p-4">
                            <div class="table-responsive">
                            <table class="table">
            <thead><!-- mapping area table header -->
                <tr ><!-- table row -->
                    <th>No</th><!-- table heading -->
                    <th>Pendidikan</th>
                    <th>Jurusan</th>
                    <th>Gelar</th>
                </tr>    
            </thead>
            <tbody ><!-- mapping area table body-->
                <tr>
                    <td align="center">1</td><!-- table data -->
                    <td>Sekolah Tinggi Terpadu Nurul Fikri</td>
                    <td>Teknik Informatika</td>
                    <td align="right">S1</td>
                </tr>
                <tr>
                    <td align="center">2</td><!-- table data -->
                    <td>Politeknik Negeri Jakarta</td>
                    <td>Teknik Komputer dan Jaringan</td>
                    <td align="right">D1</td>
                </tr> 
                <tr>
                    <td align="center">3</td><!-- table data -->
                    <td>SMK Walisongo Jakarta</td>
                    <td>Teknik Komputer dan Jaringan</td>
                    <td align="right">Lulusan SMK</td>
                </tr>   
            </tbody>
            <tfoot>
                <tr >
                    <th colspan="4">Data akan berubah jika saya kuliah lagi</th>
                </tr>  
            </tfoot>            
        </table> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Table End -->
