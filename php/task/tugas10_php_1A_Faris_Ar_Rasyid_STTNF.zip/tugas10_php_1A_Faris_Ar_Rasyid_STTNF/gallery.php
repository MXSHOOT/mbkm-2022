
            <!-- Chart Start -->
            <div class="container-fluid pt-4 px-4">
            <li data-page-no="2">
            <!-- Image Carousel -->
            <div class="mx-auto position-relative gallery-container">
              <div class="circle intro-circle-1"></div>
              <div class="circle intro-circle-2"></div>
              <div class="mx-auto tm-border-top gallery-slider">
                <figure class="effect-julia item">
                    <img src="https://1.bp.blogspot.com/-WI0znZAsmhw/U0zjJYG4_UI/AAAAAAAABAQ/vJC6qUzF87A/s1600/White-Tiger-6.jpg" alt="Image">
                    <figcaption>
                        <div>
                            <p>Harimau auuu</p>
                        </div>
                        <a href="https://1.bp.blogspot.com/-WI0znZAsmhw/U0zjJYG4_UI/AAAAAAAABAQ/vJC6qUzF87A/s1600/White-Tiger-6.jpg">View more</a>
                    </figcaption>
                </figure>
                <figure class="effect-julia item">
                    <img src="https://1.bp.blogspot.com/-hXB32hPYR3o/U0zjI6I4f3I/AAAAAAAABAI/wtvzA4RseVk/s1600/White-Tiger-5.jpg" alt="Image">
                    <figcaption>
                        <div>
                            <p>Harimau lucu</p>
                        </div>
                        <a href="https://1.bp.blogspot.com/-hXB32hPYR3o/U0zjI6I4f3I/AAAAAAAABAI/wtvzA4RseVk/s1600/White-Tiger-5.jpg">View more</a>
                    </figcaption>
                </figure>
                <figure class="effect-julia item">
                    <img src="https://1.bp.blogspot.com/-Nms-D5-7KtE/U0zjH4gEbZI/AAAAAAAAA_4/hNfEfxxxuH0/s1600/White-Tiger-3.jpg" alt="Image">
                    <figcaption>
                        <div>
                            <p>Harimau imut</p>
                        </div>
                        <a href="https://1.bp.blogspot.com/-Nms-D5-7KtE/U0zjH4gEbZI/AAAAAAAAA_4/hNfEfxxxuH0/s1600/White-Tiger-3.jpg">View more</a>
                    </figcaption>
                </figure>
                <figure class="effect-julia item">
                    <img src="https://3.bp.blogspot.com/-kBNt_gD6sGI/U0zjK2V57QI/AAAAAAAABAw/eYczYnPYic4/s1600/White-Tiger-9.jpg" alt="Image">
                    <figcaption>
                        <div>
                            <p>Hari mau</p>
                        </div>
                        <a href="https://3.bp.blogspot.com/-kBNt_gD6sGI/U0zjK2V57QI/AAAAAAAABAw/eYczYnPYic4/s1600/White-Tiger-9.jpg">View more</a>
                    </figcaption>
                </figure>
                
              </div>
            </div>
          </li>
            </div>
            <!-- Chart End -->
