<?php
interface luasBidang{
    public function luasBidang();
}