<div class="row">
    <div class="col-md-12">
        <!---------------awal konten-------------------->
        <div class="alert alert-primary" role="alert">
            Develop By: Faris Ar Rasyid 1A Kampus Merdeka
        </div>
        <!---------------akhir konten-------------------->
    </div>
</div>