<?php
interface kelilingBidang{
    public function kelilingBidang();
}