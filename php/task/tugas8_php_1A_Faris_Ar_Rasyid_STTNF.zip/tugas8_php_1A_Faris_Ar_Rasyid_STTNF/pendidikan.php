<table align="center" border="1" cellpadding="10" 
               cellspacing="0" width="60%">
            <thead><!-- mapping area table header -->
                <tr bgcolor="gray"><!-- table row -->
                    <th>No</th><!-- table heading -->
                    <th>Pendidikan</th>
                    <th>Jurusan</th>
                    <th>Gelar</th>
                </tr>    
            </thead>
            <tbody bgcolor="white"><!-- mapping area table body-->
                <tr>
                    <td align="center">1</td><!-- table data -->
                    <td>Sekolah Tinggi Terpadu Nurul Fikri</td>
                    <td>Teknik Informatika</td>
                    <td align="right">S1</td>
                </tr>
                <tr>
                    <td align="center">2</td><!-- table data -->
                    <td>Politeknik Negeri Jakarta</td>
                    <td>Teknik Komputer dan Jaringan</td>
                    <td align="right">D1</td>
                </tr> 
                <tr>
                    <td align="center">3</td><!-- table data -->
                    <td>SMK Walisongo Jakarta</td>
                    <td>Teknik Komputer dan Jaringan</td>
                    <td align="right">Lulusan SMK</td>
                </tr>   
            </tbody>
            <tfoot>
                <tr bgcolor="gray">
                    <th colspan="4">Data akan berubah jika saya kuliah lagi</th>
                </tr>  
            </tfoot>            
        </table> 