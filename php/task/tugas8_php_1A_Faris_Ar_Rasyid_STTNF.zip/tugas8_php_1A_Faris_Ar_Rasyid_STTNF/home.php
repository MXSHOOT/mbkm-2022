<figure class="text-center">
    <blockquote class="blockquote">
        <p>Hidup Hanya Sekali, Hiduplah yang Berarti</p>
    </blockquote>
    <figcaption class="blockquote-footer">
        KH. Ahmad Bisyri, Lc, MA <cite title="Source Title">Alharhum</cite>
    </figcaption>
</figure>