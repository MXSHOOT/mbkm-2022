<div class="col-md-3">
    <!---------------awal konten-------------------->
    <fieldset>
        <legend>Tautan</legend>
        <li>
            <a href="https://www.google.com/" target="_blank">Google</a>
        </li>
        <li>
            <a href="https://www.w3schools.com/" target="_blank">w3schools</a>
        </li>
        <li>
            <a href="https://www.youtube.com/" target="main">Youtube</a>
        </li>
    </fieldset> 
    <br/>
    <fieldset>
        <legend>Berita</legend>
        <p>
            Sebuah hal yang tidak terduga telah tiba sekitar 2100 tahun yang lalu, sebuah kisah 200 hari tampa mengetahui apa yang terjadi.
        </p>
    </fieldset>
    <!---------------akhir konten-------------------->
</div>