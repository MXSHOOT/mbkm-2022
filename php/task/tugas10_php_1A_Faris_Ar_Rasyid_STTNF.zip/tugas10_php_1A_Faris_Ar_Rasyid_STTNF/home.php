<li class="px-3" data-page-no="1">
            <div class="page-width-1 page-left">
              <div class="d-flex position-relative tm-border-top tm-border-bottom intro-container">
                <div class="intro-left tm-bg-dark">
                  <h2 class="mb-4">Welcome to Biodata</h2>
                  <p class="mb-4">
                    Hai! perkenalkan nama saya Faris Ar Rasyid, saya seorang manusia. saya paham ini apasih maksudnya manusia, biar kujelaskan, jadi manusia itu merupakan mahkluk yang memiliki ciri khusus yaitu bergerak dengan berfikir dan memiliki kecerdasan yang luar biasa dari mahkluk lainnya. ada yang berkata manusia adalah mahkluk sempurna yang disebabkan karena manusia merupakan satu-satunya mahkluk yang menduduki paling atas dibumi jadi wajar ada asumsi berikut, ini terjadi karena proses pikir manusia yang mengganggap demikian dari keyakinan ini manusia tidaklah memikirkan keras apa yang ia tidak ketahui dibuat tahu. alasannya mengapa? akan terjawab di paragraf berikut. </p>
                
                </div>
                <div class="intro-right">
                  <img src="https://avatars.githubusercontent.com/u/48386460?v=4" alt="Image" class="img-fluid intro-img-1">
                </div>
                <div class="circle intro-circle-1"></div>
                <div class="circle intro-circle-2"></div>
                <div class="circle intro-circle-3"></div>
                <div class="circle intro-circle-4"></div>
              </div>
              <div class="text-center">
                <a href="index.php?hal=gallery" data-page-no="2" class="btn btn-primary tm-intro-btn tm-page-link">
                  View Gallery
                </a>
              </div>            
            </div>            
          </li>